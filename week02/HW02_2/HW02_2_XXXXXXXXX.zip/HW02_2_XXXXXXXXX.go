// ชื่อ นามสกุล - ชื่อเล่น
// 6XXXXXXXX
// Lab02_1
// 204203 Sec 00B

package main

func roundToEven(x string, bPlace uint8) string {

	return ""
}
