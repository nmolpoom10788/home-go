// ชื่อ นามสกุล - ชื่อเล่น
// 6XXXXXXXX
// HW02_2
// 204203 Sec 00B

package main

import (
	"strconv"
	"strings"
)

func ipv4Encode(ipString string) uint32 {

	// numSet := strings.Split(ipString, ".")

	var result uint32 = 0


	return result

}

func ipv4Decode(ipUint uint32) string {

	var result = ""


	return result

}
